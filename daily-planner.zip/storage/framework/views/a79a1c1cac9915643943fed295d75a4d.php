<?php # [BlazeFolded]:{flux::navlist}:{D:\laravel-apps\daily-planner\vendor\livewire\flux\src/../stubs/resources/views/flux/navlist/index.blade.php}:{1786296215} ?>
<?php # [BlazeFolded]:{flux::separator}:{D:\laravel-apps\daily-planner\vendor\livewire\flux\src/../stubs/resources/views/flux/separator.blade.php}:{1786296215} ?>
<?php # [BlazeFolded]:{flux::heading}:{D:\laravel-apps\daily-planner\vendor\livewire\flux\src/../stubs/resources/views/flux/heading.blade.php}:{1786296215} ?>
<?php # [BlazeFolded]:{flux::subheading}:{D:\laravel-apps\daily-planner\vendor\livewire\flux\src/../stubs/resources/views/flux/subheading.blade.php}:{1786296215} ?>
<div class="space-y-5">
    
    <div class="flex gap-2 overflow-x-auto no-scrollbar">
        <?php ob_start(); ?><?php $__blaze->pushData(['class' => 'flex-row gap-1', 'ariaLabel' => e(__('Settings'))]); $__env->pushConsumableComponentData(['class' => 'flex-row gap-1', 'ariaLabel' => e(__('Settings'))]); ?><nav class="flex flex-col overflow-visible min-h-auto flex-row gap-1" aria-label="<?php echo e(__('Settings')); ?>" data-flux-navlist>
    <?php ob_start(); ?>
            <?php $__blaze->ensureRequired('D:\laravel-apps\daily-planner\vendor\livewire\flux\src/../stubs/resources/views/flux/navlist/item.blade.php', $__blaze->compiledPath.'/1d0470736cbf1951773e9bd8f0293098.php'); ?>
<?php if (isset($__slots1d0470736cbf1951773e9bd8f0293098)) { $__slotsStack1d0470736cbf1951773e9bd8f0293098[] = $__slots1d0470736cbf1951773e9bd8f0293098; } ?>
<?php if (isset($__attrs1d0470736cbf1951773e9bd8f0293098)) { $__attrsStack1d0470736cbf1951773e9bd8f0293098[] = $__attrs1d0470736cbf1951773e9bd8f0293098; } ?>
<?php $__attrs1d0470736cbf1951773e9bd8f0293098 = ['href' => route('profile.edit'),'wire:navigate' => true,'icon' => 'user','current' => request()->routeIs('profile.edit')]; ?>
<?php $__slots1d0470736cbf1951773e9bd8f0293098 = []; ?>
<?php $__blaze->pushData($__attrs1d0470736cbf1951773e9bd8f0293098); ?>
<?php ob_start(); ?>
                <?php echo e(__('Profile')); ?>

            <?php $__slots1d0470736cbf1951773e9bd8f0293098['slot'] = new \Illuminate\View\ComponentSlot(trim(ob_get_clean()), []); ?>
<?php $__blaze->pushSlots($__slots1d0470736cbf1951773e9bd8f0293098); ?>
<?php _1d0470736cbf1951773e9bd8f0293098($__blaze, $__attrs1d0470736cbf1951773e9bd8f0293098, $__slots1d0470736cbf1951773e9bd8f0293098, ['href', 'wire:navigate', 'current'], [], $__this ?? (isset($this) ? $this : null)); ?>
<?php if (! empty($__slotsStack1d0470736cbf1951773e9bd8f0293098)) { $__slots1d0470736cbf1951773e9bd8f0293098 = array_pop($__slotsStack1d0470736cbf1951773e9bd8f0293098); } ?>
<?php if (! empty($__attrsStack1d0470736cbf1951773e9bd8f0293098)) { $__attrs1d0470736cbf1951773e9bd8f0293098 = array_pop($__attrsStack1d0470736cbf1951773e9bd8f0293098); } ?>
<?php $__blaze->popData(); ?>
            <?php $__blaze->ensureRequired('D:\laravel-apps\daily-planner\vendor\livewire\flux\src/../stubs/resources/views/flux/navlist/item.blade.php', $__blaze->compiledPath.'/1d0470736cbf1951773e9bd8f0293098.php'); ?>
<?php if (isset($__slots1d0470736cbf1951773e9bd8f0293098)) { $__slotsStack1d0470736cbf1951773e9bd8f0293098[] = $__slots1d0470736cbf1951773e9bd8f0293098; } ?>
<?php if (isset($__attrs1d0470736cbf1951773e9bd8f0293098)) { $__attrsStack1d0470736cbf1951773e9bd8f0293098[] = $__attrs1d0470736cbf1951773e9bd8f0293098; } ?>
<?php $__attrs1d0470736cbf1951773e9bd8f0293098 = ['href' => route('security.edit'),'wire:navigate' => true,'icon' => 'shield-check','current' => request()->routeIs('security.edit')]; ?>
<?php $__slots1d0470736cbf1951773e9bd8f0293098 = []; ?>
<?php $__blaze->pushData($__attrs1d0470736cbf1951773e9bd8f0293098); ?>
<?php ob_start(); ?>
                <?php echo e(__('Security')); ?>

            <?php $__slots1d0470736cbf1951773e9bd8f0293098['slot'] = new \Illuminate\View\ComponentSlot(trim(ob_get_clean()), []); ?>
<?php $__blaze->pushSlots($__slots1d0470736cbf1951773e9bd8f0293098); ?>
<?php _1d0470736cbf1951773e9bd8f0293098($__blaze, $__attrs1d0470736cbf1951773e9bd8f0293098, $__slots1d0470736cbf1951773e9bd8f0293098, ['href', 'wire:navigate', 'current'], [], $__this ?? (isset($this) ? $this : null)); ?>
<?php if (! empty($__slotsStack1d0470736cbf1951773e9bd8f0293098)) { $__slots1d0470736cbf1951773e9bd8f0293098 = array_pop($__slotsStack1d0470736cbf1951773e9bd8f0293098); } ?>
<?php if (! empty($__attrsStack1d0470736cbf1951773e9bd8f0293098)) { $__attrs1d0470736cbf1951773e9bd8f0293098 = array_pop($__attrsStack1d0470736cbf1951773e9bd8f0293098); } ?>
<?php $__blaze->popData(); ?>
            <?php $__blaze->ensureRequired('D:\laravel-apps\daily-planner\vendor\livewire\flux\src/../stubs/resources/views/flux/navlist/item.blade.php', $__blaze->compiledPath.'/1d0470736cbf1951773e9bd8f0293098.php'); ?>
<?php if (isset($__slots1d0470736cbf1951773e9bd8f0293098)) { $__slotsStack1d0470736cbf1951773e9bd8f0293098[] = $__slots1d0470736cbf1951773e9bd8f0293098; } ?>
<?php if (isset($__attrs1d0470736cbf1951773e9bd8f0293098)) { $__attrsStack1d0470736cbf1951773e9bd8f0293098[] = $__attrs1d0470736cbf1951773e9bd8f0293098; } ?>
<?php $__attrs1d0470736cbf1951773e9bd8f0293098 = ['href' => route('appearance.edit'),'wire:navigate' => true,'icon' => 'swatch','current' => request()->routeIs('appearance.edit')]; ?>
<?php $__slots1d0470736cbf1951773e9bd8f0293098 = []; ?>
<?php $__blaze->pushData($__attrs1d0470736cbf1951773e9bd8f0293098); ?>
<?php ob_start(); ?>
                <?php echo e(__('Appearance')); ?>

            <?php $__slots1d0470736cbf1951773e9bd8f0293098['slot'] = new \Illuminate\View\ComponentSlot(trim(ob_get_clean()), []); ?>
<?php $__blaze->pushSlots($__slots1d0470736cbf1951773e9bd8f0293098); ?>
<?php _1d0470736cbf1951773e9bd8f0293098($__blaze, $__attrs1d0470736cbf1951773e9bd8f0293098, $__slots1d0470736cbf1951773e9bd8f0293098, ['href', 'wire:navigate', 'current'], [], $__this ?? (isset($this) ? $this : null)); ?>
<?php if (! empty($__slotsStack1d0470736cbf1951773e9bd8f0293098)) { $__slots1d0470736cbf1951773e9bd8f0293098 = array_pop($__slotsStack1d0470736cbf1951773e9bd8f0293098); } ?>
<?php if (! empty($__attrsStack1d0470736cbf1951773e9bd8f0293098)) { $__attrs1d0470736cbf1951773e9bd8f0293098 = array_pop($__attrsStack1d0470736cbf1951773e9bd8f0293098); } ?>
<?php $__blaze->popData(); ?>
        <?php echo trim(ob_get_clean()); ?>

</nav>
<?php $__blaze->popData(); $__env->popConsumableComponentData(); ?><?php echo ltrim(ob_get_clean()); ?>
    </div>

    <?php ob_start(); ?><div data-orientation="horizontal" role="none" class="border-0 [print-color-adjust:exact] bg-zinc-800/5 dark:bg-white/10 h-px w-full" data-flux-separator></div>
<?php echo ltrim(ob_get_clean()); ?>

    <div>
        <?php ob_start(); ?><div class="font-medium [:where(&amp;)]:text-zinc-800 [:where(&amp;)]:dark:text-white text-sm [&amp;:has(+[data-flux-subheading])]:mb-2 [[data-flux-subheading]+&amp;]:mt-2" data-flux-heading><?php ob_start(); ?><?php echo e($heading ?? ''); ?><?php echo trim(ob_get_clean()); ?></div>
<?php echo ltrim(ob_get_clean()); ?>
        <?php ob_start(); ?><div class="text-sm [:where(&amp;)]:text-zinc-500 [:where(&amp;)]:dark:text-white/70" data-flux-subheading>
    <?php ob_start(); ?><?php echo e($subheading ?? ''); ?><?php echo trim(ob_get_clean()); ?>

</div>
<?php echo ltrim(ob_get_clean()); ?>
    </div>

    <div class="w-full">
        <?php echo e($slot); ?>

    </div>
</div><?php /**PATH D:\laravel-apps\daily-planner\resources\views/pages/settings/layout.blade.php ENDPATH**/ ?>