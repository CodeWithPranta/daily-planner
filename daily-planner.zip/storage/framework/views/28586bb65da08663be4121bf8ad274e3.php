<?php # [BlazeFolded]:{flux::icon}:{D:\laravel-apps\daily-planner\vendor\livewire\flux\src/../stubs/resources/views/flux/icon/index.blade.php}:{1786296215} ?>
<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames(([
    'active' => null,
]));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter(([
    'active' => null,
]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars, $__key, $__value); ?>

<?php
    $items = [
        'home'      => ['label' => __('Home'),      'icon' => 'home',            'href' => route('dashboard')],
        'today'     => ['label' => __('Today'),     'icon' => 'clipboard-document-list', 'href' => route('today')],
        'analytics' => ['label' => __('Analytics'), 'icon' => 'chart-pie',       'href' => route('analytics')],
        'profile'   => ['label' => __('Profile'),   'icon' => 'user',            'href' => route('profile.edit')],
    ];
    // Order on screen: Home, Today, [Add Task FAB], Analytics, Profile
    $left  = ['home', 'today'];
    $right = ['analytics', 'profile'];
?>

<nav class="pt-safe fixed inset-x-0 bottom-0 z-40 mx-auto h-nav w-full max-w-md md:max-w-lg">
    <div class="relative mx-auto flex h-16 max-w-md items-end justify-around border-t border-zinc-200/80 bg-zinc-50/95 px-2 backdrop-blur-lg dark:border-zinc-800/80 dark:bg-zinc-950/95">
        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = $left; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
            <?php $item = $items[$key]; ?>
            <a href="<?php echo e($item['href']); ?>" wire:navigate
               class="flex flex-1 flex-col items-center justify-center gap-0.5 pb-1 pt-2 text-[11px] font-medium transition <?php echo e($active === $key ? 'text-brand-600 dark:text-brand-400' : 'text-zinc-500 dark:text-zinc-400'); ?>"
               aria-current="<?php echo e($active === $key ? 'page' : 'false'); ?>">
                <?php $blaze_memoized_key = \Livewire\Blaze\Memoizer\Memo::key("flux::icon", ['name' => e($item['icon']), 'class' => 'size-6', 'variant' => $active === $key ? 'solid' : 'outline']); ?><?php if ($blaze_memoized_key !== null && \Livewire\Blaze\Memoizer\Memo::has($blaze_memoized_key)) : ?><?php echo \Livewire\Blaze\Memoizer\Memo::get($blaze_memoized_key); ?><?php else : ?><?php ob_start(); ?><?php $__blaze->ensureRequired('D:\laravel-apps\daily-planner\vendor\livewire\flux\src/../stubs/resources/views/flux/icon/index.blade.php', $__blaze->compiledPath.'/8342dac67b8b21e6866e2ad39fca096f.php'); ?>
<?php $__blaze->pushData(['name' => e($item['icon']),'class' => 'size-6','variant' => $active === $key ? 'solid' : 'outline']); ?>
<?php _8342dac67b8b21e6866e2ad39fca096f($__blaze, ['name' => e($item['icon']),'class' => 'size-6','variant' => $active === $key ? 'solid' : 'outline'], [], ['variant'], [], $__this ?? (isset($this) ? $this : null)); ?>
<?php $__blaze->popData(); ?><?php $blaze_memoized_html = ob_get_clean(); ?><?php if ($blaze_memoized_key !== null) { \Livewire\Blaze\Memoizer\Memo::put($blaze_memoized_key, $blaze_memoized_html); } ?><?php echo $blaze_memoized_html; ?><?php endif; ?>
                <span><?php echo e($item['label']); ?></span>
            </a>
        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>

        
        <a href="<?php echo e(route('today', ['add' => 1])); ?>" wire:navigate
           class="relative -top-5 flex size-14 flex-none items-center justify-center rounded-full bg-brand-600 text-white shadow-lg shadow-brand-600/40 ring-4 ring-zinc-50 dark:ring-zinc-950 transition active:scale-95"
           aria-label="<?php echo e(__('Add Task')); ?>">
            <?php ob_start(); ?><svg class="shrink-0 [:where(&amp;)]:size-6 size-7" data-flux-icon xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true" data-slot="icon">
  <path fill-rule="evenodd" d="M12 3.75a.75.75 0 0 1 .75.75v6.75h6.75a.75.75 0 0 1 0 1.5h-6.75v6.75a.75.75 0 0 1-1.5 0v-6.75H4.5a.75.75 0 0 1 0-1.5h6.75V4.5a.75.75 0 0 1 .75-.75Z" clip-rule="evenodd"/>
</svg>

        <?php echo ltrim(ob_get_clean()); ?>
        </a>

        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = $right; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
            <?php $item = $items[$key]; ?>
            <a href="<?php echo e($item['href']); ?>" wire:navigate
               class="flex flex-1 flex-col items-center justify-center gap-0.5 pb-1 pt-2 text-[11px] font-medium transition <?php echo e($active === $key ? 'text-brand-600 dark:text-brand-400' : 'text-zinc-500 dark:text-zinc-400'); ?>"
               aria-current="<?php echo e($active === $key ? 'page' : 'false'); ?>">
                <?php $blaze_memoized_key = \Livewire\Blaze\Memoizer\Memo::key("flux::icon", ['name' => e($item['icon']), 'class' => 'size-6', 'variant' => $active === $key ? 'solid' : 'outline']); ?><?php if ($blaze_memoized_key !== null && \Livewire\Blaze\Memoizer\Memo::has($blaze_memoized_key)) : ?><?php echo \Livewire\Blaze\Memoizer\Memo::get($blaze_memoized_key); ?><?php else : ?><?php ob_start(); ?><?php $__blaze->ensureRequired('D:\laravel-apps\daily-planner\vendor\livewire\flux\src/../stubs/resources/views/flux/icon/index.blade.php', $__blaze->compiledPath.'/8342dac67b8b21e6866e2ad39fca096f.php'); ?>
<?php $__blaze->pushData(['name' => e($item['icon']),'class' => 'size-6','variant' => $active === $key ? 'solid' : 'outline']); ?>
<?php _8342dac67b8b21e6866e2ad39fca096f($__blaze, ['name' => e($item['icon']),'class' => 'size-6','variant' => $active === $key ? 'solid' : 'outline'], [], ['variant'], [], $__this ?? (isset($this) ? $this : null)); ?>
<?php $__blaze->popData(); ?><?php $blaze_memoized_html = ob_get_clean(); ?><?php if ($blaze_memoized_key !== null) { \Livewire\Blaze\Memoizer\Memo::put($blaze_memoized_key, $blaze_memoized_html); } ?><?php echo $blaze_memoized_html; ?><?php endif; ?>
                <span><?php echo e($item['label']); ?></span>
            </a>
        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
    </div>
</nav><?php /**PATH D:\laravel-apps\daily-planner\resources\views/components/bottom-nav.blade.php ENDPATH**/ ?>