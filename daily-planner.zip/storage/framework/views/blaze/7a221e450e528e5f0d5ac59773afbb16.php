<?php
if (!function_exists('__7a221e450e528e5f0d5ac59773afbb16')):
function __7a221e450e528e5f0d5ac59773afbb16($__blaze, $__data = [], $__slots = [], $__bound = [], $__keys = [], $__this = null) {
$__env = $__blaze->env;
$__slots['slot'] ??= new \Illuminate\View\ComponentSlot('');
if (($__data['attributes'] ?? null) instanceof \Illuminate\View\ComponentAttributeBag) { $__data = $__data + $__data['attributes']->all(); unset($__data['attributes']); }
extract($__slots, EXTR_SKIP); unset($__slots);
extract($__data, EXTR_SKIP);
$attributes = \Livewire\Blaze\Runtime\BlazeAttributeBag::make($__data, $__bound, $__keys);
unset($__data, $__bound, $__keys);
ob_start();
?>


<?php
extract(Flux::forwardedAttributes($attributes, [
    'tooltipPosition',
    'tooltipKbd',
    'tooltip',
]));
?>

<?php $tooltipPosition = $tooltipPosition ??= $attributes->pluck('tooltip:position'); ?>
<?php $tooltipKbd = $tooltipKbd ??= $attributes->pluck('tooltip:kbd'); ?>
<?php $tooltip = $tooltip ??= $attributes->pluck('tooltip'); ?>

<?php
$__defaults = [
    'tooltipPosition' => 'top',
    'tooltipKbd' => null,
    'tooltip' => null,
];
$tooltipPosition ??= $attributes['tooltip-position'] ?? $attributes['tooltipPosition'] ?? $__defaults['tooltipPosition']; unset($attributes['tooltipPosition'], $attributes['tooltip-position']);
$tooltipKbd ??= $attributes['tooltip-kbd'] ?? $attributes['tooltipKbd'] ?? $__defaults['tooltipKbd']; unset($attributes['tooltipKbd'], $attributes['tooltip-kbd']);
$tooltip ??= $attributes['tooltip'] ?? $__defaults['tooltip']; unset($attributes['tooltip']);
unset($__defaults);
?>

<?php if ($tooltip): ?>
    <?php $__blaze->ensureRequired('D:\laravel-apps\daily-planner\vendor\livewire\flux\src/../stubs/resources/views/flux/tooltip/index.blade.php', $__blaze->compiledPath.'/3322f83641a43d213fe926975a13df43.php'); ?>
<?php if (isset($__slots3322f83641a43d213fe926975a13df43)) { $__slotsStack3322f83641a43d213fe926975a13df43[] = $__slots3322f83641a43d213fe926975a13df43; } ?>
<?php if (isset($__attrs3322f83641a43d213fe926975a13df43)) { $__attrsStack3322f83641a43d213fe926975a13df43[] = $__attrs3322f83641a43d213fe926975a13df43; } ?>
<?php $__attrs3322f83641a43d213fe926975a13df43 = ['content' => $tooltip,'position' => $tooltipPosition,'kbd' => $tooltipKbd]; ?>
<?php $__slots3322f83641a43d213fe926975a13df43 = []; ?>
<?php $__blaze->pushData($__attrs3322f83641a43d213fe926975a13df43); ?>
<?php ob_start(); ?>
        <?php echo e($slot); ?>

    <?php $__slots3322f83641a43d213fe926975a13df43['slot'] = new \Illuminate\View\ComponentSlot($__blaze->processPassthroughContent('trim', trim(ob_get_clean())), []); ?>
<?php $__blaze->pushSlots($__slots3322f83641a43d213fe926975a13df43); ?>
<?php __3322f83641a43d213fe926975a13df43($__blaze, $__attrs3322f83641a43d213fe926975a13df43, $__slots3322f83641a43d213fe926975a13df43, ['content', 'position', 'kbd'], [], $__this ?? (isset($this) ? $this : null)); ?>
<?php if (! empty($__slotsStack3322f83641a43d213fe926975a13df43)) { $__slots3322f83641a43d213fe926975a13df43 = array_pop($__slotsStack3322f83641a43d213fe926975a13df43); } ?>
<?php if (! empty($__attrsStack3322f83641a43d213fe926975a13df43)) { $__attrs3322f83641a43d213fe926975a13df43 = array_pop($__attrsStack3322f83641a43d213fe926975a13df43); } ?>
<?php $__blaze->popData(); ?>
<?php else: ?>
    <?php echo e($slot); ?>

<?php endif; ?>
<?php
echo $__blaze->processPassthroughContent('ltrim', ltrim(ob_get_clean()));
} endif; ?><?php /**PATH D:\laravel-apps\daily-planner\vendor\livewire\flux\src/../stubs/resources/views/flux/with-tooltip.blade.php ENDPATH**/ ?>