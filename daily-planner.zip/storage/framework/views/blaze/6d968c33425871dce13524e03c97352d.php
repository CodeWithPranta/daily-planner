<?php
if (!function_exists('__6d968c33425871dce13524e03c97352d')):
function __6d968c33425871dce13524e03c97352d($__blaze, $__data = [], $__slots = [], $__bound = [], $__keys = [], $__this = null) {
$__env = $__blaze->env;
$__slots['slot'] ??= new \Illuminate\View\ComponentSlot('');
if (($__data['attributes'] ?? null) instanceof \Illuminate\View\ComponentAttributeBag) { $__data = $__data + $__data['attributes']->all(); unset($__data['attributes']); }
extract($__slots, EXTR_SKIP); unset($__slots);
extract($__data, EXTR_SKIP);
$attributes = \Livewire\Blaze\Runtime\BlazeAttributeBag::make($__data, $__bound, $__keys);
unset($__data, $__bound, $__keys);
ob_start();
?>


<?php
$__defaults = [
    'length' => null,
    'private' => false,
];
$length ??= $attributes['length'] ?? $__defaults['length']; unset($attributes['length']);
$private ??= $attributes['private'] ?? $__defaults['private']; unset($attributes['private']);
unset($__defaults);
?>

<?php
    $classes = Flux::classes()
        ->add('flex items-center gap-2 isolate w-fit')
        ->add('[&_[data-flux-input-group]]:w-auto')
?>

<?php $__blaze->ensureRequired('D:\laravel-apps\daily-planner\vendor\livewire\flux\src/../stubs/resources/views/flux/with-field.blade.php', $__blaze->compiledPath.'/e716859fba200f8d92d93cc23135422f.php'); ?>
<?php if (isset($__slotse716859fba200f8d92d93cc23135422f)) { $__slotsStacke716859fba200f8d92d93cc23135422f[] = $__slotse716859fba200f8d92d93cc23135422f; } ?>
<?php if (isset($__attrse716859fba200f8d92d93cc23135422f)) { $__attrsStacke716859fba200f8d92d93cc23135422f[] = $__attrse716859fba200f8d92d93cc23135422f; } ?>
<?php $__attrse716859fba200f8d92d93cc23135422f = ['attributes' => $attributes]; ?>
<?php $__slotse716859fba200f8d92d93cc23135422f = []; ?>
<?php $__blaze->pushData($__attrse716859fba200f8d92d93cc23135422f); ?>
<?php ob_start(); ?>
    <ui-otp
        <?php echo e($attributes->class($classes)); ?>

        data-flux-otp
        data-flux-control
        role="group"
        data-flux-input-aria-label="<?php echo e(__('Character {current} of {total}')); ?>"
    >
        <?php if($slot->isEmpty() && $length): ?>
            <?php for($i = 0; $i < $length; $i++): ?>
                <?php $__blaze->ensureRequired('D:\laravel-apps\daily-planner\vendor\livewire\flux\src/../stubs/resources/views/flux/otp/input.blade.php', $__blaze->compiledPath.'/26de62f6242fc892a698ac4ba592d5ce.php'); ?>
<?php $__blaze->pushData([]); ?>
<?php __26de62f6242fc892a698ac4ba592d5ce($__blaze, [], [], [], [], $__this ?? (isset($this) ? $this : null)); ?>
<?php $__blaze->popData(); ?>
            <?php endfor; ?>
        <?php else: ?>
            <?php echo e($slot); ?>

        <?php endif; ?>
    </ui-otp>
<?php $__slotse716859fba200f8d92d93cc23135422f['slot'] = new \Illuminate\View\ComponentSlot($__blaze->processPassthroughContent('trim', trim(ob_get_clean())), []); ?>
<?php $__blaze->pushSlots($__slotse716859fba200f8d92d93cc23135422f); ?>
<?php __e716859fba200f8d92d93cc23135422f($__blaze, $__attrse716859fba200f8d92d93cc23135422f, $__slotse716859fba200f8d92d93cc23135422f, ['attributes'], [], $__this ?? (isset($this) ? $this : null)); ?>
<?php if (! empty($__slotsStacke716859fba200f8d92d93cc23135422f)) { $__slotse716859fba200f8d92d93cc23135422f = array_pop($__slotsStacke716859fba200f8d92d93cc23135422f); } ?>
<?php if (! empty($__attrsStacke716859fba200f8d92d93cc23135422f)) { $__attrse716859fba200f8d92d93cc23135422f = array_pop($__attrsStacke716859fba200f8d92d93cc23135422f); } ?>
<?php $__blaze->popData(); ?><?php
echo $__blaze->processPassthroughContent('ltrim', ltrim(ob_get_clean()));
} endif; ?><?php /**PATH D:\laravel-apps\daily-planner\vendor\livewire\flux\src/../stubs/resources/views/flux/otp/index.blade.php ENDPATH**/ ?>