<?php
if (!function_exists('__e716859fba200f8d92d93cc23135422f')):
function __e716859fba200f8d92d93cc23135422f($__blaze, $__data = [], $__slots = [], $__bound = [], $__keys = [], $__this = null) {
$__env = $__blaze->env;
$__slots['slot'] ??= new \Illuminate\View\ComponentSlot('');
if (($__data['attributes'] ?? null) instanceof \Illuminate\View\ComponentAttributeBag) { $__data = $__data + $__data['attributes']->all(); unset($__data['attributes']); }
extract($__slots, EXTR_SKIP); unset($__slots);
extract($__data, EXTR_SKIP);
$attributes = \Livewire\Blaze\Runtime\BlazeAttributeBag::make($__data, $__bound, $__keys);
unset($__data, $__bound, $__keys);
ob_start();
?>


<?php
extract(Flux::forwardedAttributes($attributes, [
    'name',
    'descriptionTrailing',
    'description',
    'label',
    'badge',
]));
?>

<?php $descriptionTrailing = $descriptionTrailing ??= $attributes->pluck('description:trailing'); ?>

<?php
$__defaults = [
    'name' => $attributes->whereStartsWith('wire:model')->first(),
    'descriptionTrailing' => null,
    'description' => null,
    'label' => null,
    'badge' => null,
];
$name ??= $attributes['name'] ?? $__defaults['name']; unset($attributes['name']);
$descriptionTrailing ??= $attributes['description-trailing'] ?? $attributes['descriptionTrailing'] ?? $__defaults['descriptionTrailing']; unset($attributes['descriptionTrailing'], $attributes['description-trailing']);
$description ??= $attributes['description'] ?? $__defaults['description']; unset($attributes['description']);
$label ??= $attributes['label'] ?? $__defaults['label']; unset($attributes['label']);
$badge ??= $attributes['badge'] ?? $__defaults['badge']; unset($attributes['badge']);
unset($__defaults);
?>

<?php if (isset($label) || isset($description) || isset($descriptionTrailing)): ?>
    <?php

        $fieldAttributes = Flux::attributesAfter('field:', $attributes, []);
        $labelAttributes = Flux::attributesAfter('label:', $attributes, ['badge' => $badge]);
        $descriptionAttributes = Flux::attributesAfter('description:', $attributes, []);
        $errorAttributes = Flux::attributesAfter('error:', $attributes, ['name' => $name]);
    ?>
    <?php $__blaze->ensureRequired('D:\laravel-apps\daily-planner\vendor\livewire\flux\src/../stubs/resources/views/flux/field.blade.php', $__blaze->compiledPath.'/061363c7fb7d5364720ffac895e0eb0b.php'); ?>
<?php if (isset($__slots061363c7fb7d5364720ffac895e0eb0b)) { $__slotsStack061363c7fb7d5364720ffac895e0eb0b[] = $__slots061363c7fb7d5364720ffac895e0eb0b; } ?>
<?php if (isset($__attrs061363c7fb7d5364720ffac895e0eb0b)) { $__attrsStack061363c7fb7d5364720ffac895e0eb0b[] = $__attrs061363c7fb7d5364720ffac895e0eb0b; } ?>
<?php $__attrs061363c7fb7d5364720ffac895e0eb0b = ['attributes' => $fieldAttributes]; ?>
<?php $__slots061363c7fb7d5364720ffac895e0eb0b = []; ?>
<?php $__blaze->pushData($__attrs061363c7fb7d5364720ffac895e0eb0b); ?>
<?php ob_start(); ?>
        <?php if (isset($label)): ?>
            <?php $__blaze->ensureRequired('D:\laravel-apps\daily-planner\vendor\livewire\flux\src/../stubs/resources/views/flux/label.blade.php', $__blaze->compiledPath.'/d265eb87f67fe7ba6d90ff18987a315b.php'); ?>
<?php if (isset($__slotsd265eb87f67fe7ba6d90ff18987a315b)) { $__slotsStackd265eb87f67fe7ba6d90ff18987a315b[] = $__slotsd265eb87f67fe7ba6d90ff18987a315b; } ?>
<?php if (isset($__attrsd265eb87f67fe7ba6d90ff18987a315b)) { $__attrsStackd265eb87f67fe7ba6d90ff18987a315b[] = $__attrsd265eb87f67fe7ba6d90ff18987a315b; } ?>
<?php $__attrsd265eb87f67fe7ba6d90ff18987a315b = ['attributes' => $labelAttributes]; ?>
<?php $__slotsd265eb87f67fe7ba6d90ff18987a315b = []; ?>
<?php $__blaze->pushData($__attrsd265eb87f67fe7ba6d90ff18987a315b); ?>
<?php ob_start(); ?><?php echo e($label); ?><?php $__slotsd265eb87f67fe7ba6d90ff18987a315b['slot'] = new \Illuminate\View\ComponentSlot($__blaze->processPassthroughContent('trim', trim(ob_get_clean())), []); ?>
<?php $__blaze->pushSlots($__slotsd265eb87f67fe7ba6d90ff18987a315b); ?>
<?php __d265eb87f67fe7ba6d90ff18987a315b($__blaze, $__attrsd265eb87f67fe7ba6d90ff18987a315b, $__slotsd265eb87f67fe7ba6d90ff18987a315b, ['attributes'], [], $__this ?? (isset($this) ? $this : null)); ?>
<?php if (! empty($__slotsStackd265eb87f67fe7ba6d90ff18987a315b)) { $__slotsd265eb87f67fe7ba6d90ff18987a315b = array_pop($__slotsStackd265eb87f67fe7ba6d90ff18987a315b); } ?>
<?php if (! empty($__attrsStackd265eb87f67fe7ba6d90ff18987a315b)) { $__attrsd265eb87f67fe7ba6d90ff18987a315b = array_pop($__attrsStackd265eb87f67fe7ba6d90ff18987a315b); } ?>
<?php $__blaze->popData(); ?>
        <?php endif; ?>

        <?php if (isset($description)): ?>
            <?php $__blaze->ensureRequired('D:\laravel-apps\daily-planner\vendor\livewire\flux\src/../stubs/resources/views/flux/description.blade.php', $__blaze->compiledPath.'/5ec74dfdb249572187bae16ec6040459.php'); ?>
<?php if (isset($__slots5ec74dfdb249572187bae16ec6040459)) { $__slotsStack5ec74dfdb249572187bae16ec6040459[] = $__slots5ec74dfdb249572187bae16ec6040459; } ?>
<?php if (isset($__attrs5ec74dfdb249572187bae16ec6040459)) { $__attrsStack5ec74dfdb249572187bae16ec6040459[] = $__attrs5ec74dfdb249572187bae16ec6040459; } ?>
<?php $__attrs5ec74dfdb249572187bae16ec6040459 = ['attributes' => $descriptionAttributes]; ?>
<?php $__slots5ec74dfdb249572187bae16ec6040459 = []; ?>
<?php $__blaze->pushData($__attrs5ec74dfdb249572187bae16ec6040459); ?>
<?php ob_start(); ?><?php echo e($description); ?><?php $__slots5ec74dfdb249572187bae16ec6040459['slot'] = new \Illuminate\View\ComponentSlot($__blaze->processPassthroughContent('trim', trim(ob_get_clean())), []); ?>
<?php $__blaze->pushSlots($__slots5ec74dfdb249572187bae16ec6040459); ?>
<?php __5ec74dfdb249572187bae16ec6040459($__blaze, $__attrs5ec74dfdb249572187bae16ec6040459, $__slots5ec74dfdb249572187bae16ec6040459, ['attributes'], [], $__this ?? (isset($this) ? $this : null)); ?>
<?php if (! empty($__slotsStack5ec74dfdb249572187bae16ec6040459)) { $__slots5ec74dfdb249572187bae16ec6040459 = array_pop($__slotsStack5ec74dfdb249572187bae16ec6040459); } ?>
<?php if (! empty($__attrsStack5ec74dfdb249572187bae16ec6040459)) { $__attrs5ec74dfdb249572187bae16ec6040459 = array_pop($__attrsStack5ec74dfdb249572187bae16ec6040459); } ?>
<?php $__blaze->popData(); ?>
        <?php endif; ?>

        <?php echo e($slot); ?>


        
        [STARTCOMPILEDUNBLAZE:1TP0L1c8jR]<?php \Livewire\Blaze\Unblaze::storeScope("1TP0L1c8jR", scope: ['attributes' => $errorAttributes->getAttributes()]) ?>[ENDCOMPILEDUNBLAZE:1TP0L1c8jR]

        <?php if (isset($descriptionTrailing)): ?>
            <?php $__blaze->ensureRequired('D:\laravel-apps\daily-planner\vendor\livewire\flux\src/../stubs/resources/views/flux/description.blade.php', $__blaze->compiledPath.'/5ec74dfdb249572187bae16ec6040459.php'); ?>
<?php if (isset($__slots5ec74dfdb249572187bae16ec6040459)) { $__slotsStack5ec74dfdb249572187bae16ec6040459[] = $__slots5ec74dfdb249572187bae16ec6040459; } ?>
<?php if (isset($__attrs5ec74dfdb249572187bae16ec6040459)) { $__attrsStack5ec74dfdb249572187bae16ec6040459[] = $__attrs5ec74dfdb249572187bae16ec6040459; } ?>
<?php $__attrs5ec74dfdb249572187bae16ec6040459 = ['attributes' => $descriptionAttributes]; ?>
<?php $__slots5ec74dfdb249572187bae16ec6040459 = []; ?>
<?php $__blaze->pushData($__attrs5ec74dfdb249572187bae16ec6040459); ?>
<?php ob_start(); ?><?php echo e($descriptionTrailing); ?><?php $__slots5ec74dfdb249572187bae16ec6040459['slot'] = new \Illuminate\View\ComponentSlot($__blaze->processPassthroughContent('trim', trim(ob_get_clean())), []); ?>
<?php $__blaze->pushSlots($__slots5ec74dfdb249572187bae16ec6040459); ?>
<?php __5ec74dfdb249572187bae16ec6040459($__blaze, $__attrs5ec74dfdb249572187bae16ec6040459, $__slots5ec74dfdb249572187bae16ec6040459, ['attributes'], [], $__this ?? (isset($this) ? $this : null)); ?>
<?php if (! empty($__slotsStack5ec74dfdb249572187bae16ec6040459)) { $__slots5ec74dfdb249572187bae16ec6040459 = array_pop($__slotsStack5ec74dfdb249572187bae16ec6040459); } ?>
<?php if (! empty($__attrsStack5ec74dfdb249572187bae16ec6040459)) { $__attrs5ec74dfdb249572187bae16ec6040459 = array_pop($__attrsStack5ec74dfdb249572187bae16ec6040459); } ?>
<?php $__blaze->popData(); ?>
        <?php endif; ?>
    <?php $__slots061363c7fb7d5364720ffac895e0eb0b['slot'] = new \Illuminate\View\ComponentSlot($__blaze->processPassthroughContent('trim', trim(ob_get_clean())), []); ?>
<?php $__blaze->pushSlots($__slots061363c7fb7d5364720ffac895e0eb0b); ?>
<?php __061363c7fb7d5364720ffac895e0eb0b($__blaze, $__attrs061363c7fb7d5364720ffac895e0eb0b, $__slots061363c7fb7d5364720ffac895e0eb0b, ['attributes'], [], $__this ?? (isset($this) ? $this : null)); ?>
<?php if (! empty($__slotsStack061363c7fb7d5364720ffac895e0eb0b)) { $__slots061363c7fb7d5364720ffac895e0eb0b = array_pop($__slotsStack061363c7fb7d5364720ffac895e0eb0b); } ?>
<?php if (! empty($__attrsStack061363c7fb7d5364720ffac895e0eb0b)) { $__attrs061363c7fb7d5364720ffac895e0eb0b = array_pop($__attrsStack061363c7fb7d5364720ffac895e0eb0b); } ?>
<?php $__blaze->popData(); ?>
<?php else: ?>
    <?php echo e($slot); ?>

<?php endif; ?>
<?php
echo $__blaze->processPassthroughContent('ltrim', ltrim(ob_get_clean()));
} endif; ?><?php /**PATH D:\laravel-apps\daily-planner\vendor\livewire\flux\src/../stubs/resources/views/flux/with-field.blade.php ENDPATH**/ ?>