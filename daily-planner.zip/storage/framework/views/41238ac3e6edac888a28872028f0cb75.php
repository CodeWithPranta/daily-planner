<?php
if (!function_exists('_41238ac3e6edac888a28872028f0cb75')):
function _41238ac3e6edac888a28872028f0cb75($__blaze, $__data = [], $__slots = [], $__bound = [], $__keys = [], $__this = null) {
$__env = $__blaze->env;

if (($__data['attributes'] ?? null) instanceof \Illuminate\View\ComponentAttributeBag) { $__data = $__data + $__data['attributes']->all(); unset($__data['attributes']); }
extract($__slots, EXTR_SKIP); unset($__slots);
extract($__data, EXTR_SKIP);
$attributes = \Livewire\Blaze\Runtime\BlazeAttributeBag::make($__data, $__bound, $__keys);
unset($__data, $__bound, $__keys);
ob_start();
?>


<?php
$__defaults = [
    'iconVariant' => 'mini',
    'size' => null,
];
$iconVariant ??= $attributes['icon-variant'] ?? $attributes['iconVariant'] ?? $__defaults['iconVariant']; unset($attributes['iconVariant'], $attributes['icon-variant']);
$size ??= $attributes['size'] ?? $__defaults['size']; unset($attributes['size']);
unset($__defaults);
?>

<?php
$attributes = $attributes->merge([
    'variant' => 'subtle',
    'class' => '-me-1',
    'square' => true,
    'size' => null,
]);
?>

<?php $__blaze->ensureRequired('D:\laravel-apps\daily-planner\vendor\livewire\flux\src/../stubs/resources/views/flux/button/index.blade.php', $__blaze->compiledPath.'/d729c19578b9001ca5da1a4ab9000803.php'); ?>
<?php if (isset($__slotsd729c19578b9001ca5da1a4ab9000803)) { $__slotsStackd729c19578b9001ca5da1a4ab9000803[] = $__slotsd729c19578b9001ca5da1a4ab9000803; } ?>
<?php if (isset($__attrsd729c19578b9001ca5da1a4ab9000803)) { $__attrsStackd729c19578b9001ca5da1a4ab9000803[] = $__attrsd729c19578b9001ca5da1a4ab9000803; } ?>
<?php $__attrsd729c19578b9001ca5da1a4ab9000803 = ['attributes' => $attributes,'size' => $size === 'sm' || $size === 'xs' ? 'xs' : 'sm','xData' => 'fluxInputViewable','xOn:click' => 'toggle()','xBind:dataViewableOpen' => 'open','ariaLabel' => e(__('Toggle password visibility'))]; ?>
<?php $__slotsd729c19578b9001ca5da1a4ab9000803 = []; ?>
<?php $__blaze->pushData($__attrsd729c19578b9001ca5da1a4ab9000803); ?>
<?php ob_start(); ?>
    <?php $__blaze->ensureRequired('D:\laravel-apps\daily-planner\vendor\livewire\flux\src/../stubs/resources/views/flux/icon/eye-slash.blade.php', $__blaze->compiledPath.'/354daf2fc82bdb66dba33bd760af86d2.php'); ?>
<?php $__blaze->pushData(['variant' => $iconVariant,'class' => 'hidden [[data-viewable-open]>&]:block']); ?>
<?php _354daf2fc82bdb66dba33bd760af86d2($__blaze, ['variant' => $iconVariant,'class' => 'hidden [[data-viewable-open]>&]:block'], [], ['variant'], [], $__this ?? (isset($this) ? $this : null)); ?>
<?php $__blaze->popData(); ?>
    <?php $__blaze->ensureRequired('D:\laravel-apps\daily-planner\vendor\livewire\flux\src/../stubs/resources/views/flux/icon/eye.blade.php', $__blaze->compiledPath.'/c4487218dae73e75a17f70a14a84538c.php'); ?>
<?php $__blaze->pushData(['variant' => $iconVariant,'class' => 'block [[data-viewable-open]>&]:hidden']); ?>
<?php _c4487218dae73e75a17f70a14a84538c($__blaze, ['variant' => $iconVariant,'class' => 'block [[data-viewable-open]>&]:hidden'], [], ['variant'], [], $__this ?? (isset($this) ? $this : null)); ?>
<?php $__blaze->popData(); ?>
<?php $__slotsd729c19578b9001ca5da1a4ab9000803['slot'] = new \Illuminate\View\ComponentSlot(trim(ob_get_clean()), []); ?>
<?php $__blaze->pushSlots($__slotsd729c19578b9001ca5da1a4ab9000803); ?>
<?php _d729c19578b9001ca5da1a4ab9000803($__blaze, $__attrsd729c19578b9001ca5da1a4ab9000803, $__slotsd729c19578b9001ca5da1a4ab9000803, ['attributes', 'size'], ['xData' => 'x-data', 'xOn:click' => 'x-on:click', 'xBind:dataViewableOpen' => 'x-bind:data-viewable-open', 'ariaLabel' => 'aria-label'], $__this ?? (isset($this) ? $this : null)); ?>
<?php if (! empty($__slotsStackd729c19578b9001ca5da1a4ab9000803)) { $__slotsd729c19578b9001ca5da1a4ab9000803 = array_pop($__slotsStackd729c19578b9001ca5da1a4ab9000803); } ?>
<?php if (! empty($__attrsStackd729c19578b9001ca5da1a4ab9000803)) { $__attrsd729c19578b9001ca5da1a4ab9000803 = array_pop($__attrsStackd729c19578b9001ca5da1a4ab9000803); } ?>
<?php $__blaze->popData(); ?>
<?php
echo ltrim(ob_get_clean());
} endif; ?><?php /**PATH D:\laravel-apps\daily-planner\vendor\livewire\flux\src/../stubs/resources/views/flux/input/viewable.blade.php ENDPATH**/ ?>