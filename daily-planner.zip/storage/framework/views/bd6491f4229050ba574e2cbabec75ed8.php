<?php echo e($slot); ?>

<?php /**PATH D:\laravel-apps\daily-planner\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/footer.blade.php ENDPATH**/ ?>