<div class="mb-5">
    <h1 class="text-2xl font-bold tracking-tight"><?php echo e(__('Settings')); ?></h1>
    <p class="text-sm text-zinc-500 dark:text-zinc-400"><?php echo e(__('Manage your profile and account settings')); ?></p>
</div><?php /**PATH D:\laravel-apps\daily-planner\resources\views/partials/settings-heading.blade.php ENDPATH**/ ?>