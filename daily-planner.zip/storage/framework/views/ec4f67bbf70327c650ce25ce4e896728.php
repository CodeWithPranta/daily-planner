<?php # [BlazeFolded]:{flux::heading}:{D:\laravel-apps\daily-planner\vendor\livewire\flux\src/../stubs/resources/views/flux/heading.blade.php}:{1786296215} ?>
<?php # [BlazeFolded]:{flux::icon}:{D:\laravel-apps\daily-planner\vendor\livewire\flux\src/../stubs/resources/views/flux/icon/index.blade.php}:{1786296215} ?>
<?php # [BlazeFolded]:{flux::label}:{D:\laravel-apps\daily-planner\vendor\livewire\flux\src/../stubs/resources/views/flux/label.blade.php}:{1786296215} ?>
<?php # [BlazeFolded]:{flux::button}:{D:\laravel-apps\daily-planner\vendor\livewire\flux\src/../stubs/resources/views/flux/button/index.blade.php}:{1786296215} ?>
<?php # [BlazeFolded]:{flux::icon}:{D:\laravel-apps\daily-planner\vendor\livewire\flux\src/../stubs/resources/views/flux/icon/index.blade.php}:{1786296215} ?>
<?php # [BlazeFolded]:{flux::icon}:{D:\laravel-apps\daily-planner\vendor\livewire\flux\src/../stubs/resources/views/flux/icon/index.blade.php}:{1786296215} ?>
<?php # [BlazeFolded]:{flux::icon}:{D:\laravel-apps\daily-planner\vendor\livewire\flux\src/../stubs/resources/views/flux/icon/index.blade.php}:{1786296215} ?>
<?php # [BlazeFolded]:{flux::icon}:{D:\laravel-apps\daily-planner\vendor\livewire\flux\src/../stubs/resources/views/flux/icon/index.blade.php}:{1786296215} ?>
<?php /** @var \App\Models\TimerSession|null $session */ ?>
<div wire:poll.1s="refreshElapsed"
     x-data="{ timerOn: <?php echo e($session ? 'true' : 'false'); ?> }"
     x-effect="
         const main = document.querySelector('main');
         if (main) {
             main.classList.toggle('pb-timer', timerOn);
             main.classList.toggle('pb-nav', !timerOn);
         }
     "
>
<?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($session): ?>
    <div
        class="fixed inset-x-0 z-30 mx-auto w-full max-w-md md:max-w-lg"
        style="bottom: calc(env(safe-area-inset-bottom, 0px) + 5rem);"
    >
        <div class="mx-2 rounded-2xl border border-zinc-200/80 bg-white shadow-lg dark:border-zinc-800/80 dark:bg-zinc-900">
            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($showStopForm): ?>
                
                <div class="p-4">
                    <div class="flex items-center justify-between pb-3">
                        <?php ob_start(); ?><div class="font-medium [:where(&amp;)]:text-zinc-800 [:where(&amp;)]:dark:text-white text-sm [&amp;:has(+[data-flux-subheading])]:mb-2 [[data-flux-subheading]+&amp;]:mt-2" data-flux-heading><?php ob_start(); ?><?php echo e(__('Stop Timer')); ?><?php echo trim(ob_get_clean()); ?></div>
<?php echo ltrim(ob_get_clean()); ?>
                        <button type="button" wire:click="$set('showStopForm', false)" class="rounded-lg p-1 text-zinc-500 hover:bg-zinc-100 dark:hover:bg-zinc-800">
                            <?php ob_start(); ?><svg class="shrink-0 [:where(&amp;)]:size-6 size-4" data-flux-icon xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" aria-hidden="true" data-slot="icon">
  <path stroke-linecap="round" stroke-linejoin="round" d="M6 18 18 6M6 6l12 12"/>
</svg>

        <?php echo ltrim(ob_get_clean()); ?>
                        </button>
                    </div>
                    <div class="mb-2 text-sm text-zinc-600 dark:text-zinc-300">
                        <?php echo e($session->task->title); ?> · <span class="font-mono font-semibold"><?php echo e($elapsed); ?></span>
                    </div>
                    <form wire:submit="stopTimer" class="space-y-3">
                        <?php $__blaze->ensureRequired('D:\laravel-apps\daily-planner\vendor\livewire\flux\src/../stubs/resources/views/flux/textarea.blade.php', $__blaze->compiledPath.'/71ded2f30b7095670c75ddf1b3200e89.php'); ?>
<?php $__blaze->pushData(['wire:model' => 'stopNotes','label' => __('Notes'),'placeholder' => e(__('What did you work on?'))]); ?>
<?php _71ded2f30b7095670c75ddf1b3200e89($__blaze, ['wire:model' => 'stopNotes','label' => __('Notes'),'placeholder' => e(__('What did you work on?'))], [], ['label'], [], $__this ?? (isset($this) ? $this : null)); ?>
<?php $__blaze->popData(); ?>
                        <div class="grid gap-1.5">
                            <?php ob_start(); ?><ui-label class="inline-flex items-center text-sm font-medium  [:where(&amp;)]:text-zinc-800 [:where(&amp;)]:dark:text-white [&amp;:has([data-flux-label-trailing])]:flex" data-flux-label>
    <?php ob_start(); ?><?php echo e(__('Progress')); ?>: <span class="font-bold"><?php echo e($stopProgress); ?>%</span><?php echo trim(ob_get_clean()); ?>


    
    
    </ui-label>
<?php echo ltrim(ob_get_clean()); ?>
                            <input type="range" min="0" max="100" step="5" wire:model.live="stopProgress" class="w-full accent-brand-600" />
                        </div>
                        <?php ob_start(); ?><button type="submit" class="relative items-center font-medium justify-center gap-2 whitespace-nowrap disabled:opacity-75 dark:disabled:opacity-75 disabled:cursor-default disabled:pointer-events-none justify-center h-10 text-sm rounded-lg ps-4 pe-4 inline-flex  bg-[var(--color-accent)] hover:bg-[color-mix(in_oklab,_var(--color-accent),_transparent_10%)] text-[var(--color-accent-foreground)] border border-black/10 dark:border-0 shadow-[inset_0px_1px_--theme(--color-white/.2)] [[data-flux-button-group]_&amp;]:border-e-0 [:is([data-flux-button-group]&gt;&amp;:last-child,_[data-flux-button-group]_:last-child&gt;&amp;)]:border-e-[1px] dark:[:is([data-flux-button-group]&gt;&amp;:last-child,_[data-flux-button-group]_:last-child&gt;&amp;)]:border-e-0 dark:[:is([data-flux-button-group]&gt;&amp;:last-child,_[data-flux-button-group]_:last-child&gt;&amp;)]:border-s-[1px] [:is([data-flux-button-group]&gt;&amp;:not(:first-child),_[data-flux-button-group]_:not(:first-child)&gt;&amp;)]:border-s-[color-mix(in_srgb,var(--color-accent-foreground),transparent_85%)] *:transition-opacity [&amp;[disabled]&gt;:not([data-flux-loading-indicator])]:opacity-0 [&amp;[disabled]&gt;[data-flux-loading-indicator]]:opacity-100 [&amp;[disabled]]:pointer-events-none  w-full" data-flux-button="data-flux-button" data-flux-group-target="data-flux-group-target">
        <div class="absolute inset-0 flex items-center justify-center opacity-0" data-flux-loading-indicator>
                <svg class="shrink-0 [:where(&amp;)]:size-4 animate-spin" data-flux-icon xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" aria-hidden="true" data-slot="icon">
    <circle class="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" stroke-width="4"></circle>
    <path class="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
</svg>
                    </div>
        
        
                    
            
            <span><?php ob_start(); ?><?php echo e(__('Stop & Log')); ?><?php echo trim(ob_get_clean()); ?></span>
    </button>
<?php echo ltrim(ob_get_clean()); ?>
                    </form>
                </div>
            <?php else: ?>
                
                <div class="flex items-center gap-3 p-3">
                    <span class="flex size-10 flex-none items-center justify-center rounded-xl <?php if($session->status === \App\Enums\TimerStatus::Running): ?> bg-emerald-100 text-emerald-600 dark:bg-emerald-500/15 dark:text-emerald-400 <?php else: ?> bg-amber-100 text-amber-600 dark:bg-amber-500/15 dark:text-amber-400 <?php endif; ?>">
                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($session->status === \App\Enums\TimerStatus::Running): ?>
                            <span class="relative flex size-3">
                                <span class="absolute inline-flex size-full animate-ping rounded-full bg-emerald-500 opacity-75"></span>
                                <span class="relative inline-flex size-3 rounded-full bg-emerald-500"></span>
                            </span>
                        <?php else: ?>
                            <?php ob_start(); ?><svg class="shrink-0 [:where(&amp;)]:size-6 size-5" data-flux-icon xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true" data-slot="icon">
  <path fill-rule="evenodd" d="M6.75 5.25a.75.75 0 0 1 .75-.75H9a.75.75 0 0 1 .75.75v13.5a.75.75 0 0 1-.75.75H7.5a.75.75 0 0 1-.75-.75V5.25Zm7.5 0A.75.75 0 0 1 15 4.5h1.5a.75.75 0 0 1 .75.75v13.5a.75.75 0 0 1-.75.75H15a.75.75 0 0 1-.75-.75V5.25Z" clip-rule="evenodd"/>
</svg>

        <?php echo ltrim(ob_get_clean()); ?>
                        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                    </span>
                    <div class="min-w-0 flex-1">
                        <p class="truncate text-sm font-semibold"><?php echo e($session->task->title); ?></p>
                        <p class="font-mono text-lg font-bold tabular-nums"><?php echo e($elapsed); ?></p>
                    </div>
                    <div class="flex flex-none items-center gap-1">
                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($session->status === \App\Enums\TimerStatus::Running): ?>
                            <button type="button" wire:click="pause" wire:loading.attr="disabled" class="rounded-lg p-2.5 text-amber-600 transition hover:bg-amber-50 dark:hover:bg-amber-500/10" aria-label="<?php echo e(__('Pause')); ?>">
                                <?php ob_start(); ?><svg class="shrink-0 [:where(&amp;)]:size-6 size-5" data-flux-icon xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true" data-slot="icon">
  <path fill-rule="evenodd" d="M6.75 5.25a.75.75 0 0 1 .75-.75H9a.75.75 0 0 1 .75.75v13.5a.75.75 0 0 1-.75.75H7.5a.75.75 0 0 1-.75-.75V5.25Zm7.5 0A.75.75 0 0 1 15 4.5h1.5a.75.75 0 0 1 .75.75v13.5a.75.75 0 0 1-.75.75H15a.75.75 0 0 1-.75-.75V5.25Z" clip-rule="evenodd"/>
</svg>

        <?php echo ltrim(ob_get_clean()); ?>
                                <span wire:loading role="status" class="sr-only"><?php echo e(__('Pausing...')); ?></span>
                            </button>
                        <?php else: ?>
                            <button type="button" wire:click="resume" wire:loading.attr="disabled" class="rounded-lg p-2.5 text-emerald-600 transition hover:bg-emerald-50 dark:hover:bg-emerald-500/10" aria-label="<?php echo e(__('Resume')); ?>">
                                <?php ob_start(); ?><svg class="shrink-0 [:where(&amp;)]:size-6 size-5" data-flux-icon xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true" data-slot="icon">
  <path fill-rule="evenodd" d="M4.5 5.653c0-1.427 1.529-2.33 2.779-1.643l11.54 6.347c1.295.712 1.295 2.573 0 3.286L7.28 19.99c-1.25.687-2.779-.217-2.779-1.643V5.653Z" clip-rule="evenodd"/>
</svg>

        <?php echo ltrim(ob_get_clean()); ?>
                                <span wire:loading role="status" class="sr-only"><?php echo e(__('Resuming...')); ?></span>
                            </button>
                        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                        <button type="button" wire:click="openStopForm" class="rounded-lg p-2.5 text-rose-500 transition hover:bg-rose-50 dark:hover:bg-rose-500/10" aria-label="<?php echo e(__('Stop')); ?>">
                            <?php ob_start(); ?><svg class="shrink-0 [:where(&amp;)]:size-6 size-5" data-flux-icon xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true" data-slot="icon">
  <path fill-rule="evenodd" d="M4.5 7.5a3 3 0 0 1 3-3h9a3 3 0 0 1 3 3v9a3 3 0 0 1-3 3h-9a3 3 0 0 1-3-3v-9Z" clip-rule="evenodd"/>
</svg>

        <?php echo ltrim(ob_get_clean()); ?>
                        </button>
                    </div>
                </div>
            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
        </div>
    </div>
<?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
</div><?php /**PATH D:\laravel-apps\daily-planner\resources\views/livewire/timer/bar.blade.php ENDPATH**/ ?>