<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames(([
    'value' => 0,
    'size' => 180,
    'stroke' => 14,
    'label' => null,
    'sublabel' => null,
]));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter(([
    'value' => 0,
    'size' => 180,
    'stroke' => 14,
    'label' => null,
    'sublabel' => null,
]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars, $__key, $__value); ?>

<?php
    $value = max(0, min(100, (float) $value));
    $radius = ($size - $stroke) / 2;
    $circumference = 2 * M_PI * $radius;
    $offset = $circumference - ($value / 100) * $circumference;
    $colorClass = $value >= 75 ? 'text-emerald-500' : ($value >= 50 ? 'text-brand-500' : ($value >= 25 ? 'text-amber-500' : 'text-rose-500'));
?>

<div class="relative inline-flex items-center justify-center" style="width:<?php echo e($size); ?>px;height:<?php echo e($size); ?>px;">
    <svg width="<?php echo e($size); ?>" height="<?php echo e($size); ?>" class="-rotate-90" viewBox="0 0 <?php echo e($size); ?> <?php echo e($size); ?>">
        <circle cx="<?php echo e($size/2); ?>" cy="<?php echo e($size/2); ?>" r="<?php echo e($radius); ?>"
                stroke="currentColor" stroke-width="<?php echo e($stroke); ?>"
                class="text-zinc-200 dark:text-zinc-800" fill="none" />
        <circle cx="<?php echo e($size/2); ?>" cy="<?php echo e($size/2); ?>" r="<?php echo e($radius); ?>"
                stroke="currentColor" stroke-width="<?php echo e($stroke); ?>"
                class="<?php echo e($colorClass); ?> transition-[stroke-dashoffset] duration-700 ease-out" fill="none"
                stroke-linecap="round"
                stroke-dasharray="<?php echo e($circumference); ?>"
                stroke-dashoffset="<?php echo e($offset); ?>" />
    </svg>
    <div class="absolute flex flex-col items-center justify-center text-center">
        <span class="text-4xl font-bold tracking-tight"><?php echo e(round($value)); ?><span class="text-xl">%</span></span>
        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(isset($label)): ?>
            <span class="mt-1 text-xs font-medium text-zinc-500 dark:text-zinc-400"><?php echo e($label); ?></span>
        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(isset($sublabel)): ?>
            <span class="text-[11px] text-zinc-400 dark:text-zinc-500"><?php echo e($sublabel); ?></span>
        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
    </div>
</div><?php /**PATH D:\laravel-apps\daily-planner\resources\views/components/progress-ring.blade.php ENDPATH**/ ?>