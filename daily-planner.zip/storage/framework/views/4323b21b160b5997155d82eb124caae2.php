<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames(([
    'sidebar' => false,
]));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter(([
    'sidebar' => false,
]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars, $__key, $__value); ?>

<?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($sidebar): ?>
    <?php $__blaze->ensureRequired('D:\laravel-apps\daily-planner\vendor\livewire\flux\src/../stubs/resources/views/flux/sidebar/brand.blade.php', $__blaze->compiledPath.'/c3b6d59678332e387f35566f8d6de47a.php'); ?>
<?php if (isset($__slotsc3b6d59678332e387f35566f8d6de47a)) { $__slotsStackc3b6d59678332e387f35566f8d6de47a[] = $__slotsc3b6d59678332e387f35566f8d6de47a; } ?>
<?php if (isset($__attrsc3b6d59678332e387f35566f8d6de47a)) { $__attrsStackc3b6d59678332e387f35566f8d6de47a[] = $__attrsc3b6d59678332e387f35566f8d6de47a; } ?>
<?php $__attrsc3b6d59678332e387f35566f8d6de47a = ['name' => config('app.name', 'Laravel'),'attributes' => $attributes]; ?>
<?php $__slotsc3b6d59678332e387f35566f8d6de47a = []; ?>
<?php $__blaze->pushData($__attrsc3b6d59678332e387f35566f8d6de47a); ?>
<?php ob_start(); ?>
         <?php ob_start(); ?>
            <?php if (isset($component)) { $__componentOriginal159d6670770cb479b1921cea6416c26c = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal159d6670770cb479b1921cea6416c26c = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.app-logo-icon','data' => ['class' => 'size-5 fill-current text-white dark:text-black']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-logo-icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'size-5 fill-current text-white dark:text-black']); ?>
<?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::processComponentKey($component); ?>

<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal159d6670770cb479b1921cea6416c26c)): ?>
<?php $attributes = $__attributesOriginal159d6670770cb479b1921cea6416c26c; ?>
<?php unset($__attributesOriginal159d6670770cb479b1921cea6416c26c); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal159d6670770cb479b1921cea6416c26c)): ?>
<?php $component = $__componentOriginal159d6670770cb479b1921cea6416c26c; ?>
<?php unset($__componentOriginal159d6670770cb479b1921cea6416c26c); ?>
<?php endif; ?>
        <?php $__slotsc3b6d59678332e387f35566f8d6de47a['logo'] = new \Illuminate\View\ComponentSlot(trim(ob_get_clean()), ['class' => 'flex aspect-square size-8 items-center justify-center rounded-md bg-accent-content text-accent-foreground']); ?>
    <?php $__slotsc3b6d59678332e387f35566f8d6de47a['slot'] = new \Illuminate\View\ComponentSlot(trim(ob_get_clean()), []); ?>
<?php $__blaze->pushSlots($__slotsc3b6d59678332e387f35566f8d6de47a); ?>
<?php _c3b6d59678332e387f35566f8d6de47a($__blaze, $__attrsc3b6d59678332e387f35566f8d6de47a, $__slotsc3b6d59678332e387f35566f8d6de47a, ['name', 'attributes'], [], $__this ?? (isset($this) ? $this : null)); ?>
<?php if (! empty($__slotsStackc3b6d59678332e387f35566f8d6de47a)) { $__slotsc3b6d59678332e387f35566f8d6de47a = array_pop($__slotsStackc3b6d59678332e387f35566f8d6de47a); } ?>
<?php if (! empty($__attrsStackc3b6d59678332e387f35566f8d6de47a)) { $__attrsc3b6d59678332e387f35566f8d6de47a = array_pop($__attrsStackc3b6d59678332e387f35566f8d6de47a); } ?>
<?php $__blaze->popData(); ?>
<?php else: ?>
    <?php $__blaze->ensureRequired('D:\laravel-apps\daily-planner\vendor\livewire\flux\src/../stubs/resources/views/flux/brand.blade.php', $__blaze->compiledPath.'/c27efcb5f8806a59b333efd381e3e490.php'); ?>
<?php if (isset($__slotsc27efcb5f8806a59b333efd381e3e490)) { $__slotsStackc27efcb5f8806a59b333efd381e3e490[] = $__slotsc27efcb5f8806a59b333efd381e3e490; } ?>
<?php if (isset($__attrsc27efcb5f8806a59b333efd381e3e490)) { $__attrsStackc27efcb5f8806a59b333efd381e3e490[] = $__attrsc27efcb5f8806a59b333efd381e3e490; } ?>
<?php $__attrsc27efcb5f8806a59b333efd381e3e490 = ['name' => config('app.name', 'Laravel'),'attributes' => $attributes]; ?>
<?php $__slotsc27efcb5f8806a59b333efd381e3e490 = []; ?>
<?php $__blaze->pushData($__attrsc27efcb5f8806a59b333efd381e3e490); ?>
<?php ob_start(); ?>
         <?php ob_start(); ?>
            <?php if (isset($component)) { $__componentOriginal159d6670770cb479b1921cea6416c26c = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal159d6670770cb479b1921cea6416c26c = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.app-logo-icon','data' => ['class' => 'size-5 fill-current text-white dark:text-black']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-logo-icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'size-5 fill-current text-white dark:text-black']); ?>
<?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::processComponentKey($component); ?>

<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal159d6670770cb479b1921cea6416c26c)): ?>
<?php $attributes = $__attributesOriginal159d6670770cb479b1921cea6416c26c; ?>
<?php unset($__attributesOriginal159d6670770cb479b1921cea6416c26c); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal159d6670770cb479b1921cea6416c26c)): ?>
<?php $component = $__componentOriginal159d6670770cb479b1921cea6416c26c; ?>
<?php unset($__componentOriginal159d6670770cb479b1921cea6416c26c); ?>
<?php endif; ?>
        <?php $__slotsc27efcb5f8806a59b333efd381e3e490['logo'] = new \Illuminate\View\ComponentSlot(trim(ob_get_clean()), ['class' => 'flex aspect-square size-8 items-center justify-center rounded-md bg-accent-content text-accent-foreground']); ?>
    <?php $__slotsc27efcb5f8806a59b333efd381e3e490['slot'] = new \Illuminate\View\ComponentSlot(trim(ob_get_clean()), []); ?>
<?php $__blaze->pushSlots($__slotsc27efcb5f8806a59b333efd381e3e490); ?>
<?php _c27efcb5f8806a59b333efd381e3e490($__blaze, $__attrsc27efcb5f8806a59b333efd381e3e490, $__slotsc27efcb5f8806a59b333efd381e3e490, ['name', 'attributes'], [], $__this ?? (isset($this) ? $this : null)); ?>
<?php if (! empty($__slotsStackc27efcb5f8806a59b333efd381e3e490)) { $__slotsc27efcb5f8806a59b333efd381e3e490 = array_pop($__slotsStackc27efcb5f8806a59b333efd381e3e490); } ?>
<?php if (! empty($__attrsStackc27efcb5f8806a59b333efd381e3e490)) { $__attrsc27efcb5f8806a59b333efd381e3e490 = array_pop($__attrsStackc27efcb5f8806a59b333efd381e3e490); } ?>
<?php $__blaze->popData(); ?>
<?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
<?php /**PATH D:\laravel-apps\daily-planner\resources\views/components/app-logo.blade.php ENDPATH**/ ?>