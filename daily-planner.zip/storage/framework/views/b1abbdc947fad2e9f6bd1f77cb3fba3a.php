<?php
if (!function_exists('_b1abbdc947fad2e9f6bd1f77cb3fba3a')):
function _b1abbdc947fad2e9f6bd1f77cb3fba3a($__blaze, $__data = [], $__slots = [], $__bound = [], $__keys = [], $__this = null) {
$__env = $__blaze->env;
$__slots['slot'] ??= new \Illuminate\View\ComponentSlot('');
if (($__data['attributes'] ?? null) instanceof \Illuminate\View\ComponentAttributeBag) { $__data = $__data + $__data['attributes']->all(); unset($__data['attributes']); }
extract($__slots, EXTR_SKIP); unset($__slots);
extract($__data, EXTR_SKIP);
$attributes = \Livewire\Blaze\Runtime\BlazeAttributeBag::make($__data, $__bound, $__keys);
unset($__data, $__bound, $__keys);
ob_start();
?>


<?php $tooltipPosition = $tooltipPosition ??= $attributes->pluck('tooltip:position'); ?>
<?php $tooltipKbd = $tooltipKbd ??= $attributes->pluck('tooltip:kbd'); ?>
<?php $tooltip = $tooltip ??= $attributes->pluck('tooltip'); ?>
<?php $iconTrailing ??= $attributes->pluck('icon:trailing'); ?>
<?php $iconVariant ??= $attributes->pluck('icon:variant'); ?>

<?php
$__defaults = [
    'tooltipPosition' => 'right',
    'tooltipKbd' => null,
    'tooltip' => null,
    'iconVariant' => 'outline',
    'iconTrailing' => null,
    'badgeColor' => null,
    'iconDot' => null,
    'accent' => true,
    'badge' => null,
    'icon' => null,
];
$tooltipPosition ??= $attributes['tooltip-position'] ?? $attributes['tooltipPosition'] ?? $__defaults['tooltipPosition']; unset($attributes['tooltipPosition'], $attributes['tooltip-position']);
$tooltipKbd ??= $attributes['tooltip-kbd'] ?? $attributes['tooltipKbd'] ?? $__defaults['tooltipKbd']; unset($attributes['tooltipKbd'], $attributes['tooltip-kbd']);
$tooltip ??= $attributes['tooltip'] ?? $__defaults['tooltip']; unset($attributes['tooltip']);
$iconVariant ??= $attributes['icon-variant'] ?? $attributes['iconVariant'] ?? $__defaults['iconVariant']; unset($attributes['iconVariant'], $attributes['icon-variant']);
$iconTrailing ??= $attributes['icon-trailing'] ?? $attributes['iconTrailing'] ?? $__defaults['iconTrailing']; unset($attributes['iconTrailing'], $attributes['icon-trailing']);
$badgeColor ??= $attributes['badge-color'] ?? $attributes['badgeColor'] ?? $__defaults['badgeColor']; unset($attributes['badgeColor'], $attributes['badge-color']);
$iconDot ??= $attributes['icon-dot'] ?? $attributes['iconDot'] ?? $__defaults['iconDot']; unset($attributes['iconDot'], $attributes['icon-dot']);
$accent ??= $attributes['accent'] ?? $__defaults['accent']; unset($attributes['accent']);
$badge ??= $attributes['badge'] ?? $__defaults['badge']; unset($attributes['badge']);
$icon ??= $attributes['icon'] ?? $__defaults['icon']; unset($attributes['icon']);
unset($__defaults);
?>

<?php
$tooltip ??= $slot->isNotEmpty() ? (string) $slot : null;

// Size-up icons in square/icon-only buttons...
$iconClasses = Flux::classes('size-4')
    ->add('in-data-flux-sidebar-group-dropdown:text-zinc-400! dark:in-data-flux-sidebar-group-dropdown:text-white/80!')
    ->add('[[data-flux-sidebar-item]:hover_&]:text-current!')
    ->add('[[data-flux-sidebar-item][data-active]_&]:text-current!');

$classes = Flux::classes()
    ->add('h-8 in-data-flux-sidebar-on-mobile:h-10 relative flex items-center gap-3 rounded-lg')
    ->add('in-data-flux-sidebar-collapsed-desktop:w-10 in-data-flux-sidebar-collapsed-desktop:justify-center')
    ->add('py-0 text-start w-full px-3 has-data-flux-navlist-badge:not-in-data-flux-sidebar-collapsed-desktop:pe-1.5 my-px')
    ->add('text-zinc-500 dark:text-white/80')
    ->add(match ($accent) {
        true => [
            'data-current:text-(--color-accent-content) hover:data-current:text-(--color-accent-content)',
            'data-current:bg-white dark:data-current:bg-white/[7%] data-current:border data-current:border-zinc-200 dark:data-current:border-transparent',
            'hover:text-zinc-800 dark:hover:text-white dark:hover:bg-white/[7%] hover:bg-zinc-800/5 ',
            'border border-transparent',
        ],
        false => [
            'data-current:text-zinc-800 dark:data-current:text-zinc-100 data-current:border-zinc-200',
            'data-current:bg-white dark:data-current:bg-white/10 data-current:border data-current:border-zinc-200 dark:data-current:border-white/10 data-current:shadow-xs',
            'hover:text-zinc-800 dark:hover:text-white',
        ],
    })
    // Override the default styles to match dropdowns for when the item is inside a collapsed group dropdown...
    ->add('in-data-flux-sidebar-group-dropdown:w-auto! in-data-flux-sidebar-group-dropdown:px-2!')
    ->add('in-data-flux-sidebar-group-dropdown:focus:outline-hidden!')
    ->add('in-data-flux-sidebar-group-dropdown:text-zinc-800! in-data-flux-sidebar-group-dropdown:bg-white! in-data-flux-sidebar-group-dropdown:hover:bg-zinc-50!')
    ->add('in-data-flux-sidebar-group-dropdown:data-active:bg-zinc-50!')
    ->add('dark:in-data-flux-sidebar-group-dropdown:text-white! dark:in-data-flux-sidebar-group-dropdown:bg-transparent! dark:in-data-flux-sidebar-group-dropdown:hover:bg-zinc-600! dark:in-data-flux-sidebar-group-dropdown:data-active:bg-zinc-600!')
    ;
?>

<?php $__blaze->ensureRequired('D:\laravel-apps\daily-planner\vendor\livewire\flux\src/../stubs/resources/views/flux/tooltip/index.blade.php', $__blaze->compiledPath.'/3322f83641a43d213fe926975a13df43.php'); ?>
<?php if (isset($__slots3322f83641a43d213fe926975a13df43)) { $__slotsStack3322f83641a43d213fe926975a13df43[] = $__slots3322f83641a43d213fe926975a13df43; } ?>
<?php if (isset($__attrs3322f83641a43d213fe926975a13df43)) { $__attrsStack3322f83641a43d213fe926975a13df43[] = $__attrs3322f83641a43d213fe926975a13df43; } ?>
<?php $__attrs3322f83641a43d213fe926975a13df43 = ['position' => $tooltipPosition]; ?>
<?php $__slots3322f83641a43d213fe926975a13df43 = []; ?>
<?php $__blaze->pushData($__attrs3322f83641a43d213fe926975a13df43); ?>
<?php ob_start(); ?>
    <?php $__blaze->ensureRequired('D:\laravel-apps\daily-planner\vendor\livewire\flux\src/../stubs/resources/views/flux/button-or-link.blade.php', $__blaze->compiledPath.'/f65fa1a34f963cb0dbb8e751b376264b.php'); ?>
<?php if (isset($__slotsf65fa1a34f963cb0dbb8e751b376264b)) { $__slotsStackf65fa1a34f963cb0dbb8e751b376264b[] = $__slotsf65fa1a34f963cb0dbb8e751b376264b; } ?>
<?php if (isset($__attrsf65fa1a34f963cb0dbb8e751b376264b)) { $__attrsStackf65fa1a34f963cb0dbb8e751b376264b[] = $__attrsf65fa1a34f963cb0dbb8e751b376264b; } ?>
<?php $__attrsf65fa1a34f963cb0dbb8e751b376264b = ['attributes' => $attributes->class($classes),'dataFluxSidebarItem' => true]; ?>
<?php $__slotsf65fa1a34f963cb0dbb8e751b376264b = []; ?>
<?php $__blaze->pushData($__attrsf65fa1a34f963cb0dbb8e751b376264b); ?>
<?php ob_start(); ?>
        <?php if ($icon): ?>
            <div class="relative">
                <?php if (is_string($icon) && $icon !== ''): ?>
                    <?php $blaze_memoized_key = \Livewire\Blaze\Memoizer\Memo::key("flux::icon", ['icon' => $icon, 'variant' => $iconVariant, 'class' => $iconClasses]); ?><?php if ($blaze_memoized_key !== null && \Livewire\Blaze\Memoizer\Memo::has($blaze_memoized_key)) : ?><?php echo \Livewire\Blaze\Memoizer\Memo::get($blaze_memoized_key); ?><?php else : ?><?php ob_start(); ?><?php $__blaze->ensureRequired('D:\laravel-apps\daily-planner\vendor\livewire\flux\src/../stubs/resources/views/flux/icon/index.blade.php', $__blaze->compiledPath.'/8342dac67b8b21e6866e2ad39fca096f.php'); ?>
<?php $__blaze->pushData(['icon' => $icon,'variant' => $iconVariant,'class' => $iconClasses]); ?>
<?php _8342dac67b8b21e6866e2ad39fca096f($__blaze, ['icon' => $icon,'variant' => $iconVariant,'class' => $iconClasses], [], ['icon', 'variant'], [], $__this ?? (isset($this) ? $this : null)); ?>
<?php $__blaze->popData(); ?><?php $blaze_memoized_html = ob_get_clean(); ?><?php if ($blaze_memoized_key !== null) { \Livewire\Blaze\Memoizer\Memo::put($blaze_memoized_key, $blaze_memoized_html); } ?><?php echo $blaze_memoized_html; ?><?php endif; ?>
                <?php else: ?>
                    <?php echo e($icon); ?>

                <?php endif; ?>

                <?php if ($iconDot): ?>
                    <div class="absolute top-[-2px] end-[-2px]">
                        <div class="size-[6px] rounded-full bg-zinc-500 dark:bg-zinc-400"></div>
                    </div>
                <?php endif; ?>
            </div>
        <?php endif; ?>

        <?php if ($slot->isNotEmpty()): ?>
            <div class="
                in-data-flux-sidebar-collapsed-desktop:not-in-data-flux-sidebar-group-dropdown:hidden
                flex-1 text-sm font-medium truncate [[data-nav-footer]_&]:hidden [[data-nav-sidebar]_[data-nav-footer]_&]:block" data-content><?php echo e($slot); ?></div>
        <?php endif; ?>

        <?php if (is_string($iconTrailing) && $iconTrailing !== ''): ?>
            <?php $blaze_memoized_key = \Livewire\Blaze\Memoizer\Memo::key("flux::icon", ['icon' => $iconTrailing, 'variant' => $iconVariant, 'class' => 'in-data-flux-sidebar-collapsed-desktop:not-in-data-flux-sidebar-group-dropdown:hidden size-4!']); ?><?php if ($blaze_memoized_key !== null && \Livewire\Blaze\Memoizer\Memo::has($blaze_memoized_key)) : ?><?php echo \Livewire\Blaze\Memoizer\Memo::get($blaze_memoized_key); ?><?php else : ?><?php ob_start(); ?><?php $__blaze->ensureRequired('D:\laravel-apps\daily-planner\vendor\livewire\flux\src/../stubs/resources/views/flux/icon/index.blade.php', $__blaze->compiledPath.'/8342dac67b8b21e6866e2ad39fca096f.php'); ?>
<?php $__blaze->pushData(['icon' => $iconTrailing,'variant' => $iconVariant,'class' => 'in-data-flux-sidebar-collapsed-desktop:not-in-data-flux-sidebar-group-dropdown:hidden size-4!']); ?>
<?php _8342dac67b8b21e6866e2ad39fca096f($__blaze, ['icon' => $iconTrailing,'variant' => $iconVariant,'class' => 'in-data-flux-sidebar-collapsed-desktop:not-in-data-flux-sidebar-group-dropdown:hidden size-4!'], [], ['icon', 'variant'], [], $__this ?? (isset($this) ? $this : null)); ?>
<?php $__blaze->popData(); ?><?php $blaze_memoized_html = ob_get_clean(); ?><?php if ($blaze_memoized_key !== null) { \Livewire\Blaze\Memoizer\Memo::put($blaze_memoized_key, $blaze_memoized_html); } ?><?php echo $blaze_memoized_html; ?><?php endif; ?>
        <?php elseif ($iconTrailing): ?>
            <?php echo e($iconTrailing); ?>

        <?php endif; ?>

        <?php if (isset($badge) && $badge !== ''): ?>
            <?php $badgeAttributes = Flux::attributesAfter('badge:', $attributes, ['color' => $badgeColor]); ?>
            <?php $__blaze->ensureRequired('D:\laravel-apps\daily-planner\vendor\livewire\flux\src/../stubs/resources/views/flux/navlist/badge.blade.php', $__blaze->compiledPath.'/80d99c5c125811bf447a4f0e1f6b2247.php'); ?>
<?php if (isset($__slots80d99c5c125811bf447a4f0e1f6b2247)) { $__slotsStack80d99c5c125811bf447a4f0e1f6b2247[] = $__slots80d99c5c125811bf447a4f0e1f6b2247; } ?>
<?php if (isset($__attrs80d99c5c125811bf447a4f0e1f6b2247)) { $__attrsStack80d99c5c125811bf447a4f0e1f6b2247[] = $__attrs80d99c5c125811bf447a4f0e1f6b2247; } ?>
<?php $__attrs80d99c5c125811bf447a4f0e1f6b2247 = ['attributes' => $badgeAttributes,'class' => 'in-data-flux-sidebar-collapsed-desktop:not-in-data-flux-sidebar-group-dropdown:hidden']; ?>
<?php $__slots80d99c5c125811bf447a4f0e1f6b2247 = []; ?>
<?php $__blaze->pushData($__attrs80d99c5c125811bf447a4f0e1f6b2247); ?>
<?php ob_start(); ?><?php echo e($badge); ?><?php $__slots80d99c5c125811bf447a4f0e1f6b2247['slot'] = new \Illuminate\View\ComponentSlot(trim(ob_get_clean()), []); ?>
<?php $__blaze->pushSlots($__slots80d99c5c125811bf447a4f0e1f6b2247); ?>
<?php _80d99c5c125811bf447a4f0e1f6b2247($__blaze, $__attrs80d99c5c125811bf447a4f0e1f6b2247, $__slots80d99c5c125811bf447a4f0e1f6b2247, ['attributes'], [], $__this ?? (isset($this) ? $this : null)); ?>
<?php if (! empty($__slotsStack80d99c5c125811bf447a4f0e1f6b2247)) { $__slots80d99c5c125811bf447a4f0e1f6b2247 = array_pop($__slotsStack80d99c5c125811bf447a4f0e1f6b2247); } ?>
<?php if (! empty($__attrsStack80d99c5c125811bf447a4f0e1f6b2247)) { $__attrs80d99c5c125811bf447a4f0e1f6b2247 = array_pop($__attrsStack80d99c5c125811bf447a4f0e1f6b2247); } ?>
<?php $__blaze->popData(); ?>
        <?php endif; ?>
    <?php $__slotsf65fa1a34f963cb0dbb8e751b376264b['slot'] = new \Illuminate\View\ComponentSlot(trim(ob_get_clean()), []); ?>
<?php $__blaze->pushSlots($__slotsf65fa1a34f963cb0dbb8e751b376264b); ?>
<?php _f65fa1a34f963cb0dbb8e751b376264b($__blaze, $__attrsf65fa1a34f963cb0dbb8e751b376264b, $__slotsf65fa1a34f963cb0dbb8e751b376264b, ['attributes', 'dataFluxSidebarItem'], ['dataFluxSidebarItem' => 'data-flux-sidebar-item'], $__this ?? (isset($this) ? $this : null)); ?>
<?php if (! empty($__slotsStackf65fa1a34f963cb0dbb8e751b376264b)) { $__slotsf65fa1a34f963cb0dbb8e751b376264b = array_pop($__slotsStackf65fa1a34f963cb0dbb8e751b376264b); } ?>
<?php if (! empty($__attrsStackf65fa1a34f963cb0dbb8e751b376264b)) { $__attrsf65fa1a34f963cb0dbb8e751b376264b = array_pop($__attrsStackf65fa1a34f963cb0dbb8e751b376264b); } ?>
<?php $__blaze->popData(); ?>

    <?php $__blaze->ensureRequired('D:\laravel-apps\daily-planner\vendor\livewire\flux\src/../stubs/resources/views/flux/tooltip/content.blade.php', $__blaze->compiledPath.'/90d2e2eb24dd5acc777f734eed879f72.php'); ?>
<?php if (isset($__slots90d2e2eb24dd5acc777f734eed879f72)) { $__slotsStack90d2e2eb24dd5acc777f734eed879f72[] = $__slots90d2e2eb24dd5acc777f734eed879f72; } ?>
<?php if (isset($__attrs90d2e2eb24dd5acc777f734eed879f72)) { $__attrsStack90d2e2eb24dd5acc777f734eed879f72[] = $__attrs90d2e2eb24dd5acc777f734eed879f72; } ?>
<?php $__attrs90d2e2eb24dd5acc777f734eed879f72 = ['kbd' => $tooltipKbd,'class' => 'not-in-data-flux-sidebar-collapsed-desktop:hidden in-data-flux-sidebar-group-dropdown:hidden cursor-default']; ?>
<?php $__slots90d2e2eb24dd5acc777f734eed879f72 = []; ?>
<?php $__blaze->pushData($__attrs90d2e2eb24dd5acc777f734eed879f72); ?>
<?php ob_start(); ?>
        <?php echo e($tooltip); ?>

    <?php $__slots90d2e2eb24dd5acc777f734eed879f72['slot'] = new \Illuminate\View\ComponentSlot(trim(ob_get_clean()), []); ?>
<?php $__blaze->pushSlots($__slots90d2e2eb24dd5acc777f734eed879f72); ?>
<?php _90d2e2eb24dd5acc777f734eed879f72($__blaze, $__attrs90d2e2eb24dd5acc777f734eed879f72, $__slots90d2e2eb24dd5acc777f734eed879f72, ['kbd'], [], $__this ?? (isset($this) ? $this : null)); ?>
<?php if (! empty($__slotsStack90d2e2eb24dd5acc777f734eed879f72)) { $__slots90d2e2eb24dd5acc777f734eed879f72 = array_pop($__slotsStack90d2e2eb24dd5acc777f734eed879f72); } ?>
<?php if (! empty($__attrsStack90d2e2eb24dd5acc777f734eed879f72)) { $__attrs90d2e2eb24dd5acc777f734eed879f72 = array_pop($__attrsStack90d2e2eb24dd5acc777f734eed879f72); } ?>
<?php $__blaze->popData(); ?>
<?php $__slots3322f83641a43d213fe926975a13df43['slot'] = new \Illuminate\View\ComponentSlot(trim(ob_get_clean()), []); ?>
<?php $__blaze->pushSlots($__slots3322f83641a43d213fe926975a13df43); ?>
<?php _3322f83641a43d213fe926975a13df43($__blaze, $__attrs3322f83641a43d213fe926975a13df43, $__slots3322f83641a43d213fe926975a13df43, ['position'], [], $__this ?? (isset($this) ? $this : null)); ?>
<?php if (! empty($__slotsStack3322f83641a43d213fe926975a13df43)) { $__slots3322f83641a43d213fe926975a13df43 = array_pop($__slotsStack3322f83641a43d213fe926975a13df43); } ?>
<?php if (! empty($__attrsStack3322f83641a43d213fe926975a13df43)) { $__attrs3322f83641a43d213fe926975a13df43 = array_pop($__attrsStack3322f83641a43d213fe926975a13df43); } ?>
<?php $__blaze->popData(); ?>
<?php
echo ltrim(ob_get_clean());
} endif; ?><?php /**PATH D:\laravel-apps\daily-planner\vendor\livewire\flux\src/../stubs/resources/views/flux/sidebar/item.blade.php ENDPATH**/ ?>