<?php

use Livewire\Component;
use Livewire\Attributes\Layout;
use Livewire\Attributes\Title;

return new #[Title('Appearance settings')] #[Layout('components.app-shell', ['active' => 'profile'])] class extends Component {
    //

    protected function view($data = [])
    {
        return app('view')->file('D:\laravel-apps\daily-planner\storage\framework\views/livewire/views/abbf5bff.blade.php', $data);
    }
}; 