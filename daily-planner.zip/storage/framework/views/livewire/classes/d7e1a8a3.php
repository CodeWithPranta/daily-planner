<?php

use Livewire\Component;

return new class extends Component {
    protected function view($data = [])
    {
        return app('view')->file('D:\laravel-apps\daily-planner\storage\framework\views/livewire/views/d7e1a8a3.blade.php', $data);
    }
}; 