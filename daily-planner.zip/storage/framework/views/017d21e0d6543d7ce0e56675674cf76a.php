<?php # [BlazeFolded]:{flux::heading}:{D:\laravel-apps\daily-planner\vendor\livewire\flux\src/../stubs/resources/views/flux/heading.blade.php}:{1786296215} ?>
<?php # [BlazeFolded]:{flux::subheading}:{D:\laravel-apps\daily-planner\vendor\livewire\flux\src/../stubs/resources/views/flux/subheading.blade.php}:{1786296215} ?>
<?php # [BlazeFolded]:{flux::button}:{D:\laravel-apps\daily-planner\vendor\livewire\flux\src/../stubs/resources/views/flux/button/index.blade.php}:{1786296215} ?>
<?php # [BlazeFolded]:{flux::modal.trigger}:{D:\laravel-apps\daily-planner\vendor\livewire\flux\src/../stubs/resources/views/flux/modal/trigger.blade.php}:{1786296215} ?>
<?php
use Livewire\Component;
?>

<section class="mt-10 space-y-6">
    <div class="relative mb-5">
        <?php ob_start(); ?><div class="font-medium [:where(&amp;)]:text-zinc-800 [:where(&amp;)]:dark:text-white text-sm [&amp;:has(+[data-flux-subheading])]:mb-2 [[data-flux-subheading]+&amp;]:mt-2" data-flux-heading><?php ob_start(); ?><?php echo e(__('Delete account')); ?><?php echo trim(ob_get_clean()); ?></div>
<?php echo ltrim(ob_get_clean()); ?>
        <?php ob_start(); ?><div class="text-sm [:where(&amp;)]:text-zinc-500 [:where(&amp;)]:dark:text-white/70" data-flux-subheading>
    <?php ob_start(); ?><?php echo e(__('Delete your account and all of its resources')); ?><?php echo trim(ob_get_clean()); ?>

</div>
<?php echo ltrim(ob_get_clean()); ?>
    </div>

    <?php ob_start(); ?><div
    class="contents"
    x-data
    x-on:click="$el.querySelector('button[disabled]') || $dispatch('modal-show', { name: 'confirm-user-deletion' })"
        data-flux-modal-trigger
>
    <?php ob_start(); ?>
        <?php ob_start(); ?><button type="button" class="relative items-center font-medium justify-center gap-2 whitespace-nowrap disabled:opacity-75 dark:disabled:opacity-75 disabled:cursor-default disabled:pointer-events-none justify-center h-10 text-sm rounded-lg ps-4 pe-4 inline-flex  bg-red-500 hover:bg-red-600 dark:bg-red-600 dark:hover:bg-red-500 text-white  shadow-[inset_0px_1px_var(--color-red-500),inset_0px_2px_--theme(--color-white/.15)] dark:shadow-none [[data-flux-button-group]_&amp;]:border-e [:is([data-flux-button-group]&gt;&amp;:last-child,_[data-flux-button-group]_:last-child&gt;&amp;)]:border-e-0 [[data-flux-button-group]_&amp;]:border-red-600 dark:[[data-flux-button-group]_&amp;]:border-red-900/25" data-flux-button="data-flux-button" data-flux-group-target="data-flux-group-target" data-test="delete-user-button">
        <?php ob_start(); ?>
            <?php echo e(__('Delete account')); ?>

        <?php echo trim(ob_get_clean()); ?>

    </button>
<?php echo ltrim(ob_get_clean()); ?>
    <?php echo trim(ob_get_clean()); ?>

</div>
<?php echo ltrim(ob_get_clean()); ?>

    <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('pages::settings.delete-user-modal', []);

$__keyOuter = $__key ?? null;

$__key = null;
$__componentSlots = [];

$__key ??= \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::generateKey('lw-3660046027-0', $__key);

$__html = app('livewire')->mount($__name, $__params, $__key, $__componentSlots);

echo $__html;

unset($__html);
unset($__key);
$__key = $__keyOuter;
unset($__keyOuter);
unset($__name);
unset($__params);
unset($__componentSlots);
unset($__split);
?>
</section><?php /**PATH D:\laravel-apps\daily-planner\storage\framework\views/livewire/views/d7e1a8a3.blade.php ENDPATH**/ ?>